package com.demo.constant;

public interface ValidationConstant {
    int LENGTHUPPERBOUND = 12;
    int LENGTHLOWERBOUND = 5;
}
