package com.demo.request;

import java.util.List;

public class DeleteValidateServiceRequest {
    String serviceName;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
}
